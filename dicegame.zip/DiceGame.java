
package dicegame;
import java.util.Random;


public class DiceGame {
    
    public static void main(String[] args) {
        Random r = new Random();
        int dicePlayer;
        int dicePC;
        int mode=2; // 1-auto, 2-użytkownik
        
        Player player;
        if (mode==1) {
            player = new PlayerComp();
        } else {
            player = new PlayerHuman("Mietek");
        }
        
        
        //player.setName("You"); //set name for of your player
        
        
        
        do {
            dicePC = r.nextInt(6)+1;
            dicePlayer = player.guess();
            System.out.printf(player.getName() +" wylosował: " +dicePlayer +"\n");
            System.out.printf("Komputer wylosowa: "+dicePC+"\n");
            if (dicePlayer==dicePC) {
                System.out.printf("Wygrana! \n");
            } else {
                System.out.printf("Przegrana! \n---------------------\n");
            }
        } while (dicePlayer!=dicePC);
    }

}
